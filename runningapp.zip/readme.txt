Beste nakijker,

Hieronder enkele opmerkingen m.b.t. ons practicum.

Wij hebben in overleg met meneer Fokker ervoor gekozen om de Google Maps API voor android te gebruiken als kaart.

Wij hebben ervoor gekozen om geen "pijl" die in de richting van de orientatie van het apparaat wijst als locatie aanwijzer te maken omdat naar onze ervaring vanwege de instabiele sensor (van onze telefoons misschien)
en snel veranderende orientatie, dit geen waarde toevoegt aan de gebruikerservaring.
In plaats van de pijl hebben wij een rondje, wanneer de gebruiker zich duidelijk in een richting beweegt verschijnt er echter wel een driehoek in de richting waarin de gebruiker zich beweegt.

Om de prestatie van de app te verbeteren hebben we bij elke locatie update een nieuwe lijn tussen het vorige punt en het huidige punt getekend, dit ziet er af en toe een beetje ongelukkig uit en we zijn bezig om de lijnen vloeinder te maken
, maar zijn nog niet tot een oplossing gekomen. Dit volgt dus in practicum 3.

Met Vriendelijke Groet,

Tom Huibers - 6267661
Jan Corn� - Vink6245781